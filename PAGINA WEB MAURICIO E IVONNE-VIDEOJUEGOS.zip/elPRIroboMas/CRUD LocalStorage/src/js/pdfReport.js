// Función para mostrar alerta bonita sin usar alert()
function mostrarAlertaSinProductos() {
    // Evitar duplicar alertas
    if (document.querySelector('.alertaNoProductos')) return;

    const alerta = document.createElement('div');
    alerta.className = 'alertaNoProductos';
    alerta.textContent = 'No hay productos disponibles para generar el reporte.';

    document.body.appendChild(alerta);

    // Eliminar después de 3 segundos
    setTimeout(() => {
        alerta.remove();
    }, 3000);
}

// Importación de librería jsPDF desde window
const { jsPDF } = window.jspdf;

// Función encabezado mejorada con paginación "Hoja X de Y"
function encabezado(doc, datosImagen, posY = 30, pageNumber = 1, totalPaginas = 1) {
    doc.setFillColor(243, 243, 255);
    doc.rect(0, 0, doc.internal.pageSize.getWidth(), doc.internal.pageSize.getHeight(), "F");

    doc.setFont("Helvetica", "bold");
    doc.setFontSize(25);
    doc.setTextColor(155, 93, 229);
    doc.text(
        "REPORTE DE PRODUCTOS",
        doc.internal.pageSize.getWidth() / 2,
        posY,
        { align: "center" }
    );

    if (datosImagen) {
        doc.addImage(datosImagen, "JPEG", 15, posY - 15, 15, 15);
    }

    doc.setFontSize(10);
    doc.setTextColor(120, 120, 120);
    doc.text(
        `Hoja ${pageNumber} de ${totalPaginas}`,
        doc.internal.pageSize.getWidth() / 2,
        doc.internal.pageSize.getHeight() - 10,
        { align: "center" }
    );

    doc.setDrawColor(155, 93, 229);
    doc.setLineWidth(0.5);
    doc.line(20, posY + 5, doc.internal.pageSize.getWidth() - 20, posY + 5);
}

// Función graficarBarras
function graficarBarras(doc, categoryCounts, startY = 120, maxBarHeight = 100, horizontalMargin = 40) {
    const pageWidth = doc.internal.pageSize.getWidth();

    const totalBars = Object.keys(categoryCounts).length;
    const availableWidth = pageWidth - horizontalMargin * 2;
    const maxBarWidth = 60;

    const dynamicBarWidth = Math.min(maxBarWidth, (availableWidth / totalBars) * 0.6);
    const spacing = (availableWidth - (dynamicBarWidth * totalBars)) / (totalBars - 1);

    const maxCount = Math.max(...Object.values(categoryCounts));
    const colors = [
        [255, 99, 132], [54, 162, 235], [255, 206, 86],
        [75, 192, 192], [153, 102, 255], [255, 159, 64],
        [100, 255, 100], [200, 100, 255], [255, 100, 100],
        [100, 200, 255]
    ];

    let currentX = horizontalMargin;
    let colorIndex = 0;

    for (const [categoria, count] of Object.entries(categoryCounts)) {
        const color = colors[colorIndex % colors.length];
        const barHeight = (count / maxCount) * maxBarHeight;
        const barY = startY + (maxBarHeight - barHeight);

        doc.setFillColor(...color);
        doc.rect(currentX, barY, dynamicBarWidth, barHeight, "F");

        doc.setFontSize(10);
        doc.setTextColor(0);
        doc.setFont("Helvetica", "bold");
        doc.text(`${count}`, currentX + dynamicBarWidth / 2, startY + maxBarHeight + 5, { align: "center" });
        doc.text(categoria, currentX + dynamicBarWidth / 2, startY + maxBarHeight + 12, { align: "center" });

        currentX += dynamicBarWidth + spacing;
        colorIndex++;
    }
}

document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("btnGenerarPDF").addEventListener("click", async () => {
        try {
            const productos = JSON.parse(localStorage.getItem('productos')) || [];

            if (productos.length === 0) {
                mostrarAlertaSinProductos();
                return;
            }

            const doc = new jsPDF({
                orientation: "portrait",
                unit: "mm",
                format: "a4"
            });

            let datosImagen;
            try {
                const url = "../assets/image/logo-game shop.png";
                datosImagen = await cargarImagen(url);
            } catch (e) {
                console.warn("No se pudo cargar la imagen del logo", e);
                datosImagen = null;
            }

            const totalPaginas = 2;

            encabezado(doc, datosImagen, 30, 1, totalPaginas);

            const cuerpoTabla = productos.map(p => [
                p.id,
                p.nombre,
                p.cantidad,
                p.descripcion.substring(0, 30) + (p.descripcion.length > 30 ? "..." : ""),
                `$${parseFloat(p.precio).toFixed(2)}`,
                p.categoria,
                p.tipoVenta,
                p.fechaEmision,
                p.extra || 'N/A'
            ]);

            doc.autoTable({
                head: [["ID", "Nombre", "Cant.", "Descripción", "Precio", "Categoría", "Tipo Venta", "Fecha", "Extra"]],
                body: cuerpoTabla,
                startY: 50,
                margin: { top: 50, left: 15, right: 15 },
                styles: {
                    fontSize: 9,
                    cellPadding: 2,
                    overflow: 'linebreak'
                },
                headStyles: {
                    fillColor: [51, 124, 255],
                    textColor: 255,
                    fontSize: 10,
                    fontStyle: 'bold'
                },
                columnStyles: {
                    0: { cellWidth: 15 },
                    1: { cellWidth: 25 },
                    2: { cellWidth: 10 },
                    3: { cellWidth: 30 },
                    4: { cellWidth: 20 },
                    5: { cellWidth: 20 },
                    6: { cellWidth: 20 },
                    7: { cellWidth: 20 },
                    8: { cellWidth: 20 }
                }
            });

            doc.addPage();
            encabezado(doc, datosImagen, 30, 2, totalPaginas);

            const categoryCounts = productos.reduce((acc, p) => {
                acc[p.categoria] = (acc[p.categoria] || 0) + 1;
                return acc;
            }, {});

            graficarBarras(doc, categoryCounts, 70);

            doc.save(`Reporte_Productos_${new Date().toISOString().slice(0, 10)}.pdf`);

        } catch (error) {
            console.error("Error al generar PDF:", error);
            mostrarAlertaSinProductos();
        }
    });
});

// Cargar imagen con timeout
function cargarImagen(url, timeout = 5000) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "Anonymous";

        const timer = setTimeout(() => {
            reject(new Error("Tiempo de espera agotado al cargar imagen"));
        }, timeout);

        img.onload = () => {
            clearTimeout(timer);
            const canvas = document.createElement("canvas");
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext("2d");
            ctx.drawImage(img, 0, 0);
            resolve(canvas.toDataURL("image/jpeg", 0.7));
        };

        img.onerror = () => {
            clearTimeout(timer);
            reject(new Error("Error al cargar la imagen"));
        };

        img.src = url;
    });
}
